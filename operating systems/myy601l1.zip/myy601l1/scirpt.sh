#bash
./client -a localhost -i 1 -p &
./client -a localhost -i 1 -g &
